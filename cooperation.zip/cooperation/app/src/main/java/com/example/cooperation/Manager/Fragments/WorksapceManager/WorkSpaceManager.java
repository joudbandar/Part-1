package com.example.cooperation.Manager.Fragments.WorksapceManager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.cooperation.EventBus.PassMassageActionClick;
import com.example.cooperation.R;

import org.greenrobot.eventbus.EventBus;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


public class WorkSpaceManager extends Fragment {

    private Unbinder unbinder;

    @OnClick(R.id.view_btn_workspace1)
    void view_btn_workspace1(){
        EventBus.getDefault().postSticky(new PassMassageActionClick("ViewWorkSpaceDetials"));

    }

    public static WorkSpaceManager createFor() {
        WorkSpaceManager fragment = new WorkSpaceManager();

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_workspace_manager, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();

        unbinder = ButterKnife.bind(this, view);
        EventBus.getDefault().postSticky(new PassMassageActionClick("HiddenFloatingActionButton"));


    }

}
