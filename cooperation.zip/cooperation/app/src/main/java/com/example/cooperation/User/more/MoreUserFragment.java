package com.example.cooperation.User.more;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.example.cooperation.EventBus.PassMassageActionClick;
import com.example.cooperation.R;

import org.greenrobot.eventbus.EventBus;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


public class MoreUserFragment extends androidx.fragment.app.Fragment {

    private Unbinder unbinder;

    @BindView(R.id.arrow_back_more_user)
    ImageView arrow_back_more_user;

    @OnClick(R.id.arrow_back_more_user)
    void arrow_back_more_user_click() {
        EventBus.getDefault().postSticky(new PassMassageActionClick("BackToMain"));
    }

//    @BindView(R.id.card_coin_more_user)
//    CardView card_coin_more_user;
//
//

    @BindView(R.id.card_sign_out)
    CardView card_sign_out_more_user;

    @OnClick(R.id.card_sign_out)
    void card_sign_out_more_user_click() {

        EventBus.getDefault().postSticky(new PassMassageActionClick("SignOutMoreUser"));

    }
    @OnClick(R.id.card_profile)
    void card_profile() {

        EventBus.getDefault().postSticky(new PassMassageActionClick("OpenProfile"));

    }
    @OnClick(R.id.card_question)
    void card_question() {

        EventBus.getDefault().postSticky(new PassMassageActionClick("OpenQuestion"));

    }
    @OnClick(R.id.card_rating)
    void card_rating() {

        EventBus.getDefault().postSticky(new PassMassageActionClick("OpenRating"));

    }

    public static MoreUserFragment createFor() {
        MoreUserFragment fragment = new MoreUserFragment();

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_more_user, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        unbinder = ButterKnife.bind(this, view);

    }

    private void showDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = this.getLayoutInflater();


        builder.show();
    }

}
