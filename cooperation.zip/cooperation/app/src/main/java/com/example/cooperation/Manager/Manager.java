package com.example.cooperation.Manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;


import com.example.cooperation.EventBus.PassMassageActionClick;
import com.example.cooperation.Login;
import com.example.cooperation.Manager.Fragments.HomeManager.HomeManagerFragment;
import com.example.cooperation.Manager.Fragments.UsersManager.DisplayUsersManagerFragment;
import com.example.cooperation.Manager.Fragments.UsersManager.UsersManagerFragment;
import com.example.cooperation.Manager.Fragments.WorksapceManager.WorkSpaceManager;
import com.example.cooperation.Manager.Fragments.WorksapceManager.WorkSpaceManagerDetials;
import com.example.cooperation.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;


public class Manager extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private Toolbar toolbar;
    private DrawerLayout drawer;
    private NavigationView navigationView;

    @BindView(R.id.fab)
    FloatingActionButton fab;
    private ActionBarDrawerToggle toggle;
    private boolean mToolBarNavigationListenerIsRegistered = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_manager);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ButterKnife.bind(this);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        //Default Home
        fab.setVisibility(View.GONE);
        toolbar.setTitle("Home");

        Fragment selectedScreen = HomeManagerFragment.createFor();
        showFragment(selectedScreen);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_home_manager) {
            toolbar.setTitle(R.string.home_txt);
            Fragment selectedScreen = HomeManagerFragment.createFor();
            showFragment(selectedScreen);
        } else if (id == R.id.nav_users_management) {
            toolbar.setTitle(R.string.users_management);
            Fragment selectedScreen = UsersManagerFragment.createFor();
            showFragment(selectedScreen);
            fab.setVisibility(View.INVISIBLE);

        }else if (id == R.id.nav_workspace_management) {
            toolbar.setTitle(R.string.workspace_managment);
            Fragment selectedScreen = WorkSpaceManager.createFor();
            showFragment(selectedScreen);
            fab.setVisibility(View.INVISIBLE);

        }
        else if (id == R.id.nav_sign_out) {
            startActivity(new Intent(this, Login.class));

        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    private void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    protected void onStart() {

        super.onStart();

        EventBus.getDefault().register(this);

    }

    @Override
    protected void onStop() {
        super.onStop();

        EventBus.getDefault().unregister(this);


    }


    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    public void onPassMessageSelected(PassMassageActionClick event) {
       if (event.getMsg().equals("DisplayFloatingActionButton")) {

            fab.setVisibility(View.VISIBLE);

        }else if (event.getMsg().equals("HiddenFloatingActionButton")) {
           fab.setVisibility(View.INVISIBLE);


        } else if (event.getMsg().equals("DisplayUser")) {

           toolbar.setTitle(R.string.user_detials);

           Fragment selectedScreen = DisplayUsersManagerFragment.createFor();
           showFragment(selectedScreen);
           enableViews(false, "");
       }else if (event.getMsg().equals("ViewWorkSpaceDetials")) {

           toolbar.setTitle(R.string.workspace_title);

           Fragment selectedScreen = WorkSpaceManagerDetials.createFor();
           showFragment(selectedScreen);
           enableViews(false, "");
       }


    }


    private void enableViews(boolean enable, String FragmentBack) {


        if (enable) {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            toggle.setDrawerIndicatorEnabled(false);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

            if (!mToolBarNavigationListenerIsRegistered) {
                toggle.setToolbarNavigationClickListener(v -> {
                    if (FragmentBack.equals("ClubDetials")) {

                        enableViews(false, "");

                    } else {
                        getSupportFragmentManager().popBackStack();

                        enableViews(false, "");
                    }

                });

                mToolBarNavigationListenerIsRegistered = true;
            }

        } else {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);

            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            toggle.setDrawerIndicatorEnabled(true);
            toggle.setToolbarNavigationClickListener(v -> {

            });
            mToolBarNavigationListenerIsRegistered = false;
        }


    }

}
