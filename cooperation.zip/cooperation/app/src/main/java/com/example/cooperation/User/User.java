package com.example.cooperation.User;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;


import com.example.cooperation.Login;
import com.example.cooperation.User.BookNeedManagment.AddBookNeedManagmentFragment;
import com.example.cooperation.User.BookNeedManagment.BookManagmentFragment;
import com.example.cooperation.User.CoursesManagment.AddCourseManagmentFragment;
import com.example.cooperation.User.CoursesManagment.CourseManagmentFragment;
import com.example.cooperation.User.Home.HomeUserFragment;
import com.example.cooperation.User.WorksapceManagment.WorkSpaceManagmentFragment;
import com.example.cooperation.User.more.AddQuestionManagment;
import com.example.cooperation.User.more.RateCourseManagment;
import com.example.cooperation.User.more.UserProfile;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.cooperation.EventBus.PassMassageActionClick;
import com.example.cooperation.R;
import com.example.cooperation.User.more.MoreUserFragment;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;

public class User extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private Toolbar toolbar;


    @BindView(R.id.fab_user)
    FloatingActionButton fab;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = item -> {
        Fragment fragment;
        switch (item.getItemId()) {
            case R.id.nav_home:
                fab.setVisibility(View.GONE);
                toolbar.setTitle(getString(R.string.home_txt));

                Fragment selectedScreen = HomeUserFragment.createFor();
                showFragment(selectedScreen);
                return true;
            case R.id.nav_courses_user:
                fab.setVisibility(View.VISIBLE);
                toolbar.setTitle(getString(R.string.courses_management));

                Fragment selectedScreen2 = CourseManagmentFragment.createFor();
                showFragment(selectedScreen2);
                fab.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Fragment selectedScreen = AddCourseManagmentFragment.createFor();
                        showFragment(selectedScreen);
                        fab.setVisibility(View.GONE);

                    }
                });
                return true;
            case R.id.nav_workspace_user:
                fab.setVisibility(View.GONE);
                toolbar.setTitle(getString(R.string.workspace_txt));
                Fragment selectedScreen3 = WorkSpaceManagmentFragment.createFor();
                showFragment(selectedScreen3);
                return true;
            case R.id.nav_book_need:

                fab.setVisibility(View.VISIBLE);
                toolbar.setTitle(getString(R.string.book_need));
                Fragment selectedScreen4 = BookManagmentFragment.createFor();
                showFragment(selectedScreen4);
                fab.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Fragment selectedScreen = AddBookNeedManagmentFragment.createFor();
                        showFragment(selectedScreen);
                        fab.setVisibility(View.GONE);

                    }
                });
                return true;
            case R.id.nav_more:
                fab.setVisibility(View.GONE);
                toolbar.setTitle(getString(R.string.more_txt));
                getSupportActionBar().hide();
             //   bottomNavigationView.setVisibility(View.INVISIBLE);
        Fragment selectedScreen5 = MoreUserFragment.createFor();
        showFragment(selectedScreen5);
                return true;
        }
        return false;
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_user);
        toolbar = (Toolbar) findViewById(R.id.toolbar_user);
        setSupportActionBar(toolbar);

        getSupportActionBar().show();

        ButterKnife.bind(this);


        bottomNavigationView = findViewById(R.id.navigation_user);
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

//        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) bottomNavigationView.getLayoutParams();
//        layoutParams.setBehavior(new BottomNavigationBehavior());


        fab.setVisibility(View.GONE);
        toolbar.setTitle(getString(R.string.home_txt));

        Fragment selectedScreen = HomeUserFragment.createFor();
        showFragment(selectedScreen);

        bottomNavigationView.setVisibility(View.VISIBLE);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                EventBus.getDefault().removeAllStickyEvents();

                bottomNavigationView.setVisibility(View.VISIBLE);

                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container_user, fragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    protected void onStart() {

        super.onStart();

        EventBus.getDefault().register(this);

    }

    @Override
    protected void onStop() {
        super.onStop();

        EventBus.getDefault().unregister(this);


    }


    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    public void onPassMessageSelected(PassMassageActionClick event) {
        if (event.getMsg().equals("DisplayFloatingActionButton")) {

            fab.setVisibility(View.VISIBLE);

        }else if (event.getMsg().equals("HiddenFloatingActionButton")) {
            fab.setVisibility(View.INVISIBLE);


        }else if (event.getMsg().equals("OpenProfile")) {
            fab.setVisibility(View.GONE);
            toolbar.setTitle(getString(R.string.profile_txt));

            Fragment selectedScreen = UserProfile.createFor();
            showFragment(selectedScreen);

            //toolBar(true, getString(R.string.payment_txt));
          //  bottomNavigationView.setVisibility(View.INVISIBLE);
        }else if (event.getMsg().equals("OpenQuestion")) {
            fab.setVisibility(View.GONE);
            toolbar.setTitle(getString(R.string.hire_questions));

            Fragment selectedScreen = AddQuestionManagment.createFor();
            showFragment(selectedScreen);

            //toolBar(true, getString(R.string.payment_txt));
            //  bottomNavigationView.setVisibility(View.INVISIBLE);
        }else if (event.getMsg().equals("OpenRating")) {
            fab.setVisibility(View.GONE);
            toolbar.setTitle(getString(R.string.rating_txt));

            Fragment selectedScreen = RateCourseManagment.createFor();
            showFragment(selectedScreen);

            //toolBar(true, getString(R.string.payment_txt));
            //  bottomNavigationView.setVisibility(View.INVISIBLE);
        }else if (event.getMsg().equals("SignOutMoreUser")) {
            // clearAllIntentExtras(getIntent());

            Intent intent = new Intent(User.this, Login.class);
            finish();
            startActivity(intent);
            //System.exit(0);
        }

    }

}
