package com.example.cooperation.User.WorksapceManagment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import com.example.cooperation.EventBus.PassMassageActionClick;
import com.example.cooperation.R;

import org.greenrobot.eventbus.EventBus;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import cn.pedant.SweetAlert.SweetAlertDialog;


public class WorkSpaceManagmentFragment extends androidx.fragment.app.Fragment {

    private Unbinder unbinder;

    @BindView(R.id.join_btn)
    Button join_btn;
    @OnClick(R.id.join_btn)
    void joined_btn_click(){
        showDialog();
    }

    public static WorkSpaceManagmentFragment createFor() {
        WorkSpaceManagmentFragment fragment = new WorkSpaceManagmentFragment();

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_workspace_mangement, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        unbinder = ButterKnife.bind(this, view);
        EventBus.getDefault().postSticky(new PassMassageActionClick("HiddenFloatingActionButton"));


    }

    private void showDialog() {

        SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(getContext(), SweetAlertDialog.NORMAL_TYPE);
        View itemView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_request_join, null);

        sweetAlertDialog.setCustomView(itemView).show();

        Button btn =  sweetAlertDialog.findViewById(R.id.confirm_button);
        btn.setText("Request");
        btn.setBackgroundColor(ContextCompat.getColor(getContext(),R.color.thirdColor));

    }

}
