package com.example.cooperation.Manager.Fragments.UsersManager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


import com.example.cooperation.EventBus.PassMassageActionClick;
import com.example.cooperation.R;

import org.greenrobot.eventbus.EventBus;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;




public class UsersManagerFragment extends Fragment {

    private static final String EXTRA_TEXT = "text";
    private Unbinder unbinder;

    @BindView(R.id.view_user_detial_btn)
    Button view_user_detial_btn;

    @OnClick(R.id.view_user_detial_btn)
    void view_user_detial_btn_btn_click() {
        EventBus.getDefault().postSticky(new PassMassageActionClick("DisplayUser"));

    }

    public static UsersManagerFragment createFor() {
        UsersManagerFragment fragment = new UsersManagerFragment();

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_users_manager, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        final String text = args != null ? args.getString(EXTRA_TEXT) : "";

        unbinder = ButterKnife.bind(this, view);


    }

}
