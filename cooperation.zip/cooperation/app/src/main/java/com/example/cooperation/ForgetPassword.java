package com.example.cooperation;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.FirebaseAuth;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;


public class ForgetPassword extends AppCompatActivity {




    @BindView(R.id.back_login_btn)
    TextView back_login_btn;

    @BindView(R.id.rest_password_email_data)
    EditText edt_forget_email;
    String Email;

    @BindView(R.id.rest_password_btn)
    Button reset_password_btn;

    @OnClick(R.id.back_login_btn)
    void clicklogin_back() {
        startActivity(new Intent(this, Login.class));


    }

    @OnClick(R.id.rest_password_btn)
    void reset_password_btn_btn() {
        ResetPassword();

    }

    private void ResetPassword() {
        Email = edt_forget_email.getText().toString();
        if (!(TextUtils.isEmpty(Email))) {
            SendResetPassword(Email);
        } else {
            edt_forget_email.setError("please ,write mail");
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rest_password);
        ButterKnife.bind(this);
    }

    private void SendResetPassword(String email) {
        FirebaseAuth auth = FirebaseAuth.getInstance();

        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener((OnCompleteListener<Void>) task -> {
                    if (task.isSuccessful()) {
                        SuccedSend();

                        // do something when mail was sent successfully.
                    } else {
                        EmailVaildation();
                    }
                });
    }

    private void EmailVaildation() {
        SweetAlertDialog pDialogSuccess = new SweetAlertDialog(ForgetPassword.this, SweetAlertDialog.WARNING_TYPE);
        pDialogSuccess.setTitleText(getString(R.string.email_not_found));
        pDialogSuccess.setConfirmText(getString(R.string.done_txt));
        pDialogSuccess.setConfirmClickListener(sweetAlertDialog -> {
            sweetAlertDialog.dismiss();

            edt_forget_email.setError("please Re-write Email ");

        });
        pDialogSuccess.setCancelable(true);
        pDialogSuccess.show();
    }

    private void SuccedSend() {
        SweetAlertDialog pDialogSuccess = new SweetAlertDialog(ForgetPassword.this, SweetAlertDialog.SUCCESS_TYPE);
        pDialogSuccess.setTitleText(getString(R.string.suceessfully_sended));
        pDialogSuccess.setConfirmText(getString(R.string.done_txt));
        pDialogSuccess.setConfirmClickListener(sweetAlertDialog -> {
            edt_forget_email.setText("");

            sweetAlertDialog.dismiss();
        });
        pDialogSuccess.setCancelable(true);
        pDialogSuccess.show();
    }



}

