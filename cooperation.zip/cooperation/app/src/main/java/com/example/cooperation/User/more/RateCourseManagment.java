package com.example.cooperation.User.more;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.cooperation.EventBus.PassMassageActionClick;
import com.example.cooperation.R;

import org.greenrobot.eventbus.EventBus;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import cn.pedant.SweetAlert.SweetAlertDialog;


public class RateCourseManagment extends androidx.fragment.app.Fragment {

    private Unbinder unbinder;
@BindView(R.id.rate_course)
Button rate_course;

@OnClick(R.id.rate_course)
void course_rating(){
    SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(getContext(), SweetAlertDialog.NORMAL_TYPE);
    View itemView = LayoutInflater.from(getContext()).inflate(R.layout.rating_item, null);

    sweetAlertDialog.setCustomView(itemView).show();

    Button btn =  sweetAlertDialog.findViewById(R.id.confirm_button);
    btn.setText("Rate");
    btn.setBackgroundColor(ContextCompat.getColor(getContext(),R.color.thirdColor));
}


    public static RateCourseManagment createFor() {
        RateCourseManagment fragment = new RateCourseManagment();

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_rate_course, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        unbinder = ButterKnife.bind(this, view);

    }

    private void showDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = this.getLayoutInflater();
        EventBus.getDefault().postSticky(new PassMassageActionClick("HiddenFloatingActionButton"));


        builder.show();
    }

}
