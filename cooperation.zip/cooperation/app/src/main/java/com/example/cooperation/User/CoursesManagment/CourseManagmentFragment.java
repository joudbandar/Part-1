package com.example.cooperation.User.CoursesManagment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.example.cooperation.R;

import butterknife.ButterKnife;
import butterknife.Unbinder;


public class CourseManagmentFragment extends androidx.fragment.app.Fragment {

    private Unbinder unbinder;



    public static CourseManagmentFragment createFor() {
        CourseManagmentFragment fragment = new CourseManagmentFragment();

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_course_mangement, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        unbinder = ButterKnife.bind(this, view);

    }

    private void showDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = this.getLayoutInflater();


        builder.show();
    }

}
