package com.example.cooperation;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cooperation.Common.common;
import com.example.cooperation.Manager.Manager;
import com.example.cooperation.Model.UserModel;
import com.example.cooperation.User.User;
import com.example.cooperation.User.Vistor;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.greenrobot.eventbus.EventBus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;

import static com.example.cooperation.Common.common.PREFS_NAME;
import static com.example.cooperation.Common.common.PREF_PASSWORD;
import static com.example.cooperation.Common.common.PREF_USERNAME;


public class Login extends AppCompatActivity {



    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private FirebaseAuth auth;

    private SweetAlertDialog pDialogLoading;
    private SweetAlertDialog pDialogRegister;



    @BindView(R.id.login_email_data)
    EditText login_email_edt;
    String Email;

    @BindView(R.id.login_password_data)
    EditText login_password_input;
    String Password;

    @OnClick(R.id.registration_link)
    void enter_register_click() {
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
    }
    @OnClick(R.id.forget_password_link)
    void reset_btn_click() {
        Intent intent = new Intent(this, ForgetPassword.class);
        startActivity(intent);
    }
    @OnClick(R.id.skip_btn)
    void skip_btn() {
        Intent intent = new Intent(this, Vistor.class);
        startActivity(intent);
    }
    @OnClick(R.id.login_btn)
    void login_btn_click() {
        SignIn();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        ButterKnife.bind(this);

        initFirebase();

    }
    void login(){
//        if((login_email_data.getText().toString().equals("admin")) ||(login_password_data.getText().toString().equals("admin"))){
//            Intent intent = new Intent(this, Manager.class);
//            startActivity(intent);
//        }else{
//            Intent intent = new Intent(this, User.class);
//            startActivity(intent);
//        }
    }
    private void initFirebase() {
        auth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    public void SignIn() {
        Email = login_email_edt.getText().toString();
        Password = login_password_input.getText().toString();


        if (!(TextUtils.isEmpty(Email))) {
            if (common.isValidEmail(Email)) {
                if (!(TextUtils.isEmpty(Password))) {
                    if (common.isValidPassword(Password)) {
                        if (Email.equals("manager@mail.com") && Password.equals("A12345@")) {

                            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                                    .edit()
                                    .putString(PREF_USERNAME, Email)
                                    .putString(PREF_PASSWORD, Password)
                                    .apply();

                            startActivity(new Intent(this, Manager.class));
                        } else {
                            pDialogLoading = new SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                            pDialogLoading.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
                            pDialogLoading.setTitleText("Signing in");
                            pDialogLoading.setCancelable(false);
                            pDialogLoading.show();

                            SignInUser(Email, Password);

                        }
                    } else {
                        login_password_input.setError("The password must contain an uppercase letter, a lowercase letter, and a symbol, and must be at least 6 characters long");
                        login_password_input.requestFocus();
                    }
                } else {
                    login_password_input.setError("Please type the password ");
                    login_password_input.requestFocus();
                }
            } else {
                login_email_edt.setError("Please write the email correctly\n\n" +
                        " ex@gmail.com");
                login_email_edt.requestFocus();
            }
        } else {
            login_email_edt.setError("Please write an email");
            login_email_edt.requestFocus();
        }

    }

    private void SignInUser(String email, String password) {

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        databaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.child(common.USERS_KEY).child(getuID()).exists()) {

                                    UserModel userModel = dataSnapshot.child(getuID()).getValue(UserModel.class);
                                    common.currentUser = userModel;
                                    EventBus.getDefault().removeAllStickyEvents();

                                    Intent intent = new Intent(Login.this, User.class);
                                    startActivity(intent);

                                } else {
                                    CheckRegister();

                                    //  auth.getCurrentUser().delete();
                                }
                                pDialogLoading.dismiss();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(Login.this, "" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                    } else {
                        pDialogLoading.dismiss();

                        CheckRegister();
                    }
                });
    }


    private void CheckRegister() {
        pDialogRegister = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        pDialogRegister.setTitleText("Login failed. Please check the data and make sure it is correct");
        pDialogRegister.setConfirmText("close");
        pDialogRegister.setConfirmClickListener(sweetAlertDialog -> {

            pDialogRegister.dismiss();
            pDialogLoading.dismiss();


        });
        pDialogRegister.setCancelable(false);
        pDialogRegister.show();

        pDialogLoading.dismiss();
    }


    private String getuID() {
        String id = FirebaseAuth.getInstance().getCurrentUser().getUid();
        return id;
    }

}

