package com.example.cooperation;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cooperation.Common.common;
import com.example.cooperation.Model.UserModel;
import com.example.cooperation.User.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.pedant.SweetAlert.SweetAlertDialog;


public class Register extends AppCompatActivity {


    private FirebaseAuth auth;

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;

    private SweetAlertDialog pDialog;



    @BindView(R.id.first_name_data)
    EditText edt_name_register;

    private String Name_register;

    @BindView(R.id.email_edt_register)
    EditText edt_mail_register;
    private String mail_register;

    @BindView(R.id.faculty_edt)
    EditText faculty_edt;
    private String Faculty_regeister;


    @BindView(R.id.password_data)
    EditText edt_password_register;
    private String password_register;



    @BindView(R.id.registration_btn)
    Button register_btn;


    @OnClick(R.id.login_link)
    void login_btn_click() {
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }
    @OnClick(R.id.registration_btn)
    void registration_btn() {
        register();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registraion);
        getSupportActionBar().hide();

        ButterKnife.bind(this);
        initFirebase();



    }
    private void initFirebase() {
        auth = FirebaseAuth.getInstance();

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

    }


    public void register() {
        Name_register = edt_name_register.getText().toString();
        mail_register = edt_mail_register.getText().toString();
        Faculty_regeister = faculty_edt.getText().toString();
        password_register = edt_password_register.getText().toString();

        if (!(TextUtils.isEmpty(Name_register))) {
            if (!(TextUtils.isEmpty(mail_register))) {
                if (common.isValidEmail(mail_register)) {
                    if (!(TextUtils.isEmpty(Faculty_regeister))) {
                        if (!(TextUtils.isEmpty(password_register))) {
                            if (common.isValidPassword(password_register)) {
                                                pDialog = new SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                                                pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
                                                pDialog.setTitleText("Sending request");
                                                pDialog.setCancelable(false);
                                                pDialog.show();
                                                createUser(Name_register, mail_register, Faculty_regeister, password_register);
                                            } else {
                                edt_password_register.setError("The password must contain an uppercase letter, a lowercase letter, and a symbol, and must be at least 6 characters long");
                                edt_password_register.requestFocus();
                            }
                        } else {
                            edt_password_register.setError("Please type the password");
                            edt_password_register.requestFocus();
                        }

                } else {
                        faculty_edt.setError("Please write college");
                        faculty_edt.requestFocus();
                    }
                }
                else {
                    edt_mail_register.setError("Please write the email correctly " +
                            "(ex@gmail.com)");
                    edt_mail_register.requestFocus();
                }
            } else {
                edt_mail_register.setError("Please write an email");
                edt_mail_register.requestFocus();
            }
        } else {
            edt_name_register.setError("Please write an email");
            edt_name_register.requestFocus();

        }
    }




    private void createUser(final String username, final String email, final String faculty,final String password) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String id = task.getResult().getUser().getUid();
                        saveTodb(username, email, faculty, password, id);
                    } else {
                        pDialog.dismiss();
                        Toast.makeText(this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void saveTodb(String username, String email, String faculty, String password, String id) {

        UserModel userModel = new UserModel(id, username, email, password,faculty);
        databaseReference.child(common.USERS_KEY).child(id).setValue(userModel);

        pDialog.dismiss();
        startActivity(new Intent(getApplicationContext(), User.class));
        finish();
    }

    public void already(View view) {
        startActivity(new Intent(getApplicationContext(), Login.class));
    }

}

